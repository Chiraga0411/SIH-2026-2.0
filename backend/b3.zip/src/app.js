const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const parcelRoutes = require("./routes/parcelRoutes");
const authRoutes = require("./routes/authRoutes");
const claimRoutes = require("./routes/claimRoutes");
const listingRoutes = require("./routes/listingRoutes");
const consentRoutes = require("./routes/consentRoutes");
const registrationRoutes = require("./routes/registrationRoutes");
const workflowRoutes = require("./routes/workflowRoutes");

function createApp() {
  const app = express();
  if (process.env.TRUST_PROXY) app.set("trust proxy", Number(process.env.TRUST_PROXY) || process.env.TRUST_PROXY);
  app.disable("x-powered-by");

  const origins = (process.env.FRONTEND_ORIGIN || "http://localhost:5173").split(",").map((o) => o.trim()).filter(Boolean);
  app.use(helmet({ contentSecurityPolicy: false })); // API returns JSON; /docs loads Swagger from a CDN
  app.use(cors({ origin: origins }));
  app.use(express.json({ limit: "1mb" }));

  app.use("/api/auth", authRoutes);
  app.use("/api/parcels", parcelRoutes);
  app.use("/api/claims", claimRoutes);
  app.use("/api/listings", listingRoutes);
  app.use("/api/consents", consentRoutes);
  app.use("/api/registrations", registrationRoutes);
  app.use("/api", workflowRoutes);

const openapi = {
  openapi: "3.0.3",
  info: { title: "LandStack API", version: "1.1.0", description: "Verified land records, consent, services and audit APIs." },
  servers: [{ url: "/api" }],
  security: [{ bearerAuth: [] }],
  components: { securitySchemes: { bearerAuth: { type: "http", scheme: "bearer", bearerFormat: "JWT" } } },
  paths: {
    "/auth/register": { post: { security: [], summary: "Create citizen account (name, phone, email, password) and send phone OTP" } },
    "/auth/register/verify": { post: { security: [], summary: "Verify registration OTP" } },
    "/auth/login": { post: { security: [], summary: "Citizen password check, then send login OTP" } },
    "/auth/login/verify": { post: { security: [], summary: "Verify login OTP and receive JWT" } },
    "/auth/resend-otp": { post: { security: [], summary: "Resend OTP (30s cooldown)" } },
    "/auth/official-login": { post: { security: [], summary: "Official employee ID + password login" } },
    "/auth/me": { get: { summary: "Current user" } },
    "/parcels": { get: { summary: "List parcels" } },
    "/parcels/{ulpin}": { get: { summary: "Get parcel" } },
    "/claims": { post: { summary: "Claim a parcel" } },
    "/alerts": { get: { summary: "List role-scoped risk alerts" } },
    "/audit-log": { get: { summary: "List audit events" } },
    "/services": { get: { summary: "List eight land services" } },
    "/services/{id}": { get: { summary: "Run an instant service check" } },
    "/service-requests": { get: { summary: "List service requests" }, post: { summary: "Create certificate request" } },
    "/service-requests/{id}": { patch: { summary: "Approve or reject service request" } },
    "/service-requests/{id}/certificate": { get: { summary: "Download issued certificate" } }
  }
};
app.get("/openapi.json", (req, res) => res.json(openapi));
app.get("/docs", (req, res) => res.type("html").send(`<!doctype html><html><head><title>LandStack Swagger</title><link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css"></head><body><div id="swagger-ui"></div><script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script><script>window.onload=()=>SwaggerUIBundle({url:'/openapi.json',dom_id:'#swagger-ui'})</script></body></html>`));

  app.get("/", (req, res) => {
    res.json({ name: "LandStack API", status: "ok", version: "1.1.0", docs: "/docs", openapi: "/openapi.json" });
  });

  // Malformed JSON and other client errors keep their status; everything else is a generic 500.
  app.use((err, req, res, next) => {
    if (err && err.status && err.status < 500) return res.status(err.status).json({ message: "Invalid request" });
    console.error(err);
    res.status(500).json({ message: "Unexpected server error" });
  });

  return app;
}

module.exports = createApp;
