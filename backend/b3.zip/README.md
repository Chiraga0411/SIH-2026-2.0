# LandStack backend

Express 5 + MongoDB (Mongoose). Run on port 5000.

## Setup
    npm install
    cp .env.example .env        # then fill in MONGO_URI and JWT_SECRET (see comments in the file)
    npm run seed:officials      # creates official accounts; prints their passwords ONCE
    npm run dev
    npm test                    # runs without a database

The server refuses to start if `JWT_SECRET` is missing or under 32 characters, and in production if `SMS_PROVIDER` is `console`.

## Authentication
**Citizens** (email + password created at sign-up, plus a one-time code sent to their email; SMS is available via `OTP_CHANNEL=sms`):
1. `POST /api/auth/register` {name, phone, email, password, district?, circle?, mauza?} sends an OTP
2. `POST /api/auth/register/verify` {phone, otp} returns `{token, user}`
3. `POST /api/auth/login` {identifier (phone or email), password} checks the password and sends an OTP; no token yet
4. `POST /api/auth/login/verify` {identifier, otp} returns `{token, user}`
5. `POST /api/auth/resend-otp` {identifier, purpose: "login"|"register"} (30 s cooldown)

**Officials:** `POST /api/auth/official-login` {employeeId, password}. Accounts come from `npm run seed:officials` (roles: officer, registrar, planner, auditor, admin).

`GET /api/auth/me` returns the current user. Send `Authorization: Bearer <token>` on protected routes. The role is always read from the database, never trusted from the token.

## OTP and login protections
6-digit code from `crypto.randomInt`, stored as an HMAC (never plaintext), 5-minute expiry, single use, max 5 attempts, new code replaces the old one, 30 s resend cooldown. Account locks for 15 min after 5 wrong passwords. SMS-sending routes are rate limited per IP and per phone/identifier. Wrong password and unknown account return the same response.

## Delivering the OTP
Default is **email** (`OTP_CHANNEL=email`). Set `MAIL_PROVIDER` to:
- `console`: dev only. The code is printed in the server terminal. Refused in production.
- `smtp`: e.g. Gmail with an App password (`SMTP_HOST=smtp.gmail.com`, `SMTP_PORT=465`). Some free hosts block outgoing SMTP ports, so test this on your host.
- `brevo` or `resend`: plain HTTPS APIs that work on any host. Brevo only needs a verified sender address; Resend needs a verified domain to email anyone but yourself.

`OTP_CHANNEL=sms` uses `SMS_PROVIDER` (`twilio` or `msg91`) and needs India's DLT registration. Provider code is unit-tested against mocked services only, so send one real code from your deployed server before relying on it.

## Known limitations / next steps
- In email mode the phone number is collected but not verified, so don't use it as proof of identity. There is no password-reset flow yet (it could reuse the email OTP).
- Officials sign in with password only. Consider TOTP for admin and registrar roles.
- JWT lives 8 h and cannot be revoked individually (deactivating a user does block it). Add refresh tokens if you need shorter sessions.
- Rate limits are in-memory (per process). Use a shared store such as Redis if you run several instances.
