require("dotenv").config();
const connectDB = require("./config/db");
const createApp = require("./app");

const secret = process.env.JWT_SECRET || "";
if (secret.length < 32) {
  console.error("JWT_SECRET is missing or shorter than 32 characters. Refusing to start.");
  console.error('Generate one with: node -e "console.log(require(\'crypto\').randomBytes(48).toString(\'hex\'))"');
  process.exit(1);
}
if (process.env.NODE_ENV === "production" && (process.env.SMS_PROVIDER || "console") === "console") {
  console.error("SMS_PROVIDER must be a real provider (twilio or msg91) in production. Refusing to start.");
  process.exit(1);
}

connectDB();

const PORT = process.env.PORT || 5000;
createApp().listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
