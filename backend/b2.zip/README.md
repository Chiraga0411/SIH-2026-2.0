# LandStack backend

Express 5 + MongoDB (Mongoose). Run on port 5000.

## Setup
    npm install
    cp .env.example .env        # then fill in MONGO_URI and JWT_SECRET (see comments in the file)
    npm run seed:officials      # creates official accounts; prints their passwords ONCE
    npm run dev
    npm test                    # runs without a database

The server refuses to start if `JWT_SECRET` is missing or under 32 characters, and in production if `SMS_PROVIDER` is `console`.

## Authentication
**Citizens** (email + password created at sign-up, plus phone OTP):
1. `POST /api/auth/register` {name, phone, email, password, district?, circle?, mauza?} sends an OTP
2. `POST /api/auth/register/verify` {phone, otp} returns `{token, user}`
3. `POST /api/auth/login` {identifier (phone or email), password} checks the password and sends an OTP; no token yet
4. `POST /api/auth/login/verify` {identifier, otp} returns `{token, user}`
5. `POST /api/auth/resend-otp` {identifier, purpose: "login"|"register"} (30 s cooldown)

**Officials:** `POST /api/auth/official-login` {employeeId, password}. Accounts come from `npm run seed:officials` (roles: officer, registrar, planner, auditor, admin).

`GET /api/auth/me` returns the current user. Send `Authorization: Bearer <token>` on protected routes. The role is always read from the database, never trusted from the token.

## OTP and login protections
6-digit code from `crypto.randomInt`, stored as an HMAC (never plaintext), 5-minute expiry, single use, max 5 attempts, new code replaces the old one, 30 s resend cooldown. Account locks for 15 min after 5 wrong passwords. SMS-sending routes are rate limited per IP and per phone/identifier. Wrong password and unknown account return the same response.

## SMS
`SMS_PROVIDER=console` (dev: prints the OTP in the server log), `twilio`, or `msg91`. Twilio and MSG91 are implemented but have not been run against the live services; send a test OTP before launch. MSG91 needs a DLT-approved template.

## Known limitations / next steps
- Email is collected but not verified. Add an email OTP before relying on it for account recovery. There is no password-reset flow yet.
- Officials sign in with password only. Consider TOTP for admin and registrar roles.
- JWT lives 8 h and cannot be revoked individually (deactivating a user does block it). Add refresh tokens if you need shorter sessions.
- Rate limits are in-memory (per process). Use a shared store such as Redis if you run several instances.
